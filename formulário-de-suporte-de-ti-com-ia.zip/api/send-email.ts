// This file should be placed in an `api` directory at the project root (e.g., /api/send-email.ts).
// It acts as a secure backend function that runs on a server, not in the browser.

interface EmailPayload {
  to: string;
  subject: string;
  htmlBody: string;
}

// This function is designed to work in a serverless environment (e.g., Vercel, Netlify).
// It safely handles your secret API key and communicates with the Resend email service.
export default async function handler(request: Request): Promise<Response> {
  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ message: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // IMPORTANT: Get the API Key from environment variables.
  // This is a secure way to store secrets. You must configure this in your hosting provider's settings.
  const resendApiKey = process.env.RESEND_API_KEY;
  if (!resendApiKey) {
      console.error('RESEND_API_KEY environment variable not set.');
      return new Response(JSON.stringify({ message: 'Server configuration error: Email API key is missing.' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json' },
      });
  }

  try {
    const { to, subject, htmlBody } = (await request.json()) as EmailPayload;

    const resendPayload = {
      from: 'onboarding@resend.dev', // This is a default address that works for testing. For production, verify your own domain in Resend.
      to: to.split(',').map(email => email.trim()), // Resend API expects an array of email addresses.
      subject: subject,
      html: htmlBody,
    };

    // Make the actual API call to Resend.
    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify(resendPayload),
    });

    if (!resendResponse.ok) {
      const errorData = await resendResponse.json();
      console.error('Resend API Error:', errorData);
      return new Response(JSON.stringify({ message: 'Failed to send email via provider.', details: errorData }), {
        status: resendResponse.status,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await resendResponse.json();

    return new Response(JSON.stringify({ message: 'Email sent successfully!', data }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in send-email handler:', error);
    return new Response(JSON.stringify({ message: 'An internal server error occurred.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
