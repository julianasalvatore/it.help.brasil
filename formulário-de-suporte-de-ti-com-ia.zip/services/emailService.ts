import { SupportTicketData, TicketAnalysisResult } from '../types';

/**
 * This service now makes a real API call to a secure backend endpoint.
 * The backend is responsible for handling the secret API key and sending the email.
 */
export const sendSupportEmail = async (formData: SupportTicketData, analysis: TicketAnalysisResult): Promise<void> => {
  // If 'Outro:' was selected, the `equipamento` string is already combined in the formData from App.tsx.
  const { nome, email, setor, equipamento, descricao, unidade } = formData;
  
  const supportEmail = 'juliana.lira@inspirededu.com';
  const subject = `Head Office Brasil - Suporte a ${setor} - ${nome} - ${equipamento}`;

  const htmlBody = `
  <div style="width: 100%; font-family: 'Segoe UI', sans-serif; background-color: #f9f9f9;">
    <div style="background-color: #3f8fdfe3; color: white; padding: 16px;">
      <h2 style="margin: 0; font-size: 18px;">Novo Chamado Head Office Brasil</h2>
    </div>
    <div style="padding: 20px; color: #333; background-color: #ffffff;">
      <p style="margin: 10px 0;"><strong>👤 Solicitante:</strong> ${nome}</p>
      <p style="margin: 10px 0;"><strong>📧 E-mail:</strong> ${email}</p>
      <p style="margin: 10px 0;"><strong>🏫 Unidade:</strong> ${unidade}</p>
      <p style="margin: 10px 0;"><strong>🏢 Setor:</strong> ${setor}</p>
      <p style="margin: 10px 0;"><strong>💻 Equipamento:</strong> ${equipamento}</p>
      <p style="margin: 10px 0;"><strong>📝 Descrição do problema:</strong> ${descricao}</p>
      <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">
      <h3 style="font-size: 16px; color: #444;">Análise Inicial da IA</h3>
      <p style="margin: 10px 0;"><strong>Prioridade:</strong> ${analysis.priority}</p>
      <p style="margin: 10px 0;"><strong>Categoria:</strong> ${analysis.category}</p>
      <p style="margin: 10px 0;"><strong>Sugestão:</strong> ${analysis.suggested_solution}</p>
    </div>
    <div style="background-color: #f1f1f1; color: #555; font-size: 12px; padding: 10px;">
      Sistema de Chamados SD+ · Head Office Brasil<br>
      Desenvolvido por Roberto Carneiro<br>
      <span style="color:#555; text-decoration:none;">Ajustes e aprimoramentos por Juli&#8203;ana Lira</span>
    </div>
  </div>
  `;

  const emailPayload = {
    to: `${supportEmail}, ${email}`,
    subject: subject,
    htmlBody: htmlBody,
  };

  try {
    // Call the backend serverless function
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailPayload),
    });

    if (!response.ok) {
      // Try to parse the error message from the backend
      const errorData = await response.json().catch(() => ({ message: 'Failed to send email and could not parse error response.' }));
      throw new Error(errorData.message || 'Falha ao enviar e-mail.');
    }
    // If we get here, the email was sent successfully
  } catch (error) {
    console.error('Email sending error:', error);
    // Re-throw the error so the UI can catch it and display a message to the user
    if (error instanceof Error) {
        throw new Error(`Erro de comunicação ao enviar e-mail: ${error.message}`);
    }
    throw new Error('Ocorreu um erro desconhecido ao tentar enviar o e-mail.');
  }
};
