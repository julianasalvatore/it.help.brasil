import { GoogleGenAI, Type } from "@google/genai";
import { SupportTicketData, TicketAnalysisResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    priority: {
      type: Type.STRING,
      description: "A prioridade do ticket (Alta, Média, Baixa).",
    },
    category: {
      type: Type.STRING,
      description: "A categoria do problema (ex: Hardware, Software, Rede, Acesso).",
    },
    suggested_solution: {
      type: Type.STRING,
      description: "Uma sugestão de primeiro passo para resolver o problema ou para o técnico de suporte investigar.",
    },
  },
  required: ["priority", "category", "suggested_solution"],
};


export const analyzeTicket = async (formData: SupportTicketData): Promise<TicketAnalysisResult> => {
  const { nome, setor, equipamento, descricao, unidade } = formData;

  const prompt = `
    Você é um especialista em suporte de TI. Analise o seguinte ticket de suporte e forneça uma avaliação estruturada em JSON.

    Detalhes do Ticket:
    - Nome do Solicitante: ${nome}
    - Unidade/Escola: ${unidade}
    - Setor: ${setor}
    - Equipamento Envolvido: ${equipamento}
    - Descrição do Problema: ${descricao}

    Com base na descrição, determine a prioridade do ticket (Alta, Média, Baixa), categorize o problema (ex: Hardware, Software, Rede, Acesso) e sugira uma solução inicial ou um próximo passo para a equipe de suporte.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      },
    });

    const jsonText = response.text.trim();
    // Gemini may still return markdown, so we strip it.
    const cleanedJson = jsonText.replace(/^```json\s*|```\s*$/g, '');
    const parsedResult = JSON.parse(cleanedJson) as TicketAnalysisResult;
    return parsedResult;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Falha ao analisar o ticket com a API Gemini: ${error.message}`);
    }
    throw new Error("Ocorreu um erro desconhecido ao analisar o ticket.");
  }
};