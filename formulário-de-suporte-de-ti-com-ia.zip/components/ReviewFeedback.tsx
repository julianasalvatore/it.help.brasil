import React from 'react';
import { TicketAnalysisResult, TicketPriority } from '../types';

interface TicketAnalysisProps {
  result: TicketAnalysisResult;
}

const priorityConfig: Record<string, { color: string; bg: string; label: string }> = {
  [TicketPriority.Alta]: { color: 'text-red-800', bg: 'bg-red-100', label: 'Prioridade Alta' },
  [TicketPriority.Media]: { color: 'text-yellow-800', bg: 'bg-yellow-100', label: 'Prioridade Média' },
  [TicketPriority.Baixa]: { color: 'text-blue-800', bg: 'bg-blue-100', label: 'Prioridade Baixa' },
};

const TicketAnalysis: React.FC<TicketAnalysisProps> = ({ result }) => {
  if (!result) {
    return null;
  }

  const config = priorityConfig[result.priority] || { color: 'text-gray-800', bg: 'bg-gray-100', label: result.priority };

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6 mt-8">
      <h3 className="text-2xl font-bold text-gray-900 mb-4 border-b pb-3">Análise do Ticket de Suporte</h3>
      
      <div className="space-y-6">
        <div>
          <h4 className="text-sm font-semibold text-gray-600 uppercase tracking-wider">Prioridade</h4>
          <span className={`mt-1 inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.color}`}>
            {config.label}
          </span>
        </div>

        <div>
          <h4 className="text-sm font-semibold text-gray-600 uppercase tracking-wider">Categoria</h4>
          <p className="text-lg text-gray-800 mt-1">{result.category}</p>
        </div>

        <div className="mt-2 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <h4 className="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Sugestão de Resolução</h4>
          <p className="text-gray-800 whitespace-pre-wrap">{result.suggested_solution}</p>
        </div>
      </div>
    </div>
  );
};

export default TicketAnalysis;
