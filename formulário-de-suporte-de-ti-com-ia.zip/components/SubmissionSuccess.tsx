import React from 'react';
import Button from './Button';

interface SubmissionSuccessProps {
  email: string;
  onReset: () => void;
}

const SubmissionSuccess: React.FC<SubmissionSuccessProps> = ({ email, onReset }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-6 text-center">
      <svg className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      <h3 className="mt-4 text-2xl font-bold text-gray-900">Ticket Enviado com Sucesso!</h3>
      <div className="mt-2 text-md text-gray-600">
        <p>Sua solicitação de suporte foi registrada.</p>
        <p className="mt-1">
          Uma cópia de confirmação foi enviada para <strong>{email}</strong>.
          Nossa equipe revisará a análise da IA e entrará em contato em breve.
        </p>
      </div>
      <div className="mt-6">
        <Button onClick={onReset} type="button">
          Abrir Novo Chamado
        </Button>
      </div>
    </div>
  );
};

export default SubmissionSuccess;
