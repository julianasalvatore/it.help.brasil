
import React from 'react';

interface TextInputProps {
  id: string;
  // FIX: Add `name` prop to TextInputProps to resolve TypeScript error in App.tsx. The `name` prop is necessary for the `handleInputChange` function.
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder: string;
  type?: string;
}

const TextInput: React.FC<TextInputProps> = ({ id, name, value, onChange, placeholder, type = 'text' }) => {
  return (
    <div className="w-full">
      <input
        id={id}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-1/2 bg-transparent border-b border-gray-300 py-2 text-gray-700 focus:outline-none focus:border-indigo-500 transition-colors duration-300"
      />
    </div>
  );
};

export default TextInput;
