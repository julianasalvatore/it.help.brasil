import React from 'react';

export interface OptionGroup {
  label: string;
  options: string[];
}

export interface SelectGroupProps {
  id: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  optionGroups: (string | OptionGroup)[]; // Can be a simple string or a group
}

const SelectGroup: React.FC<SelectGroupProps> = ({ id, name, value, onChange, optionGroups }) => {
  return (
    <select
      id={id}
      name={name}
      value={value}
      onChange={onChange}
      className="w-full mt-2 p-3 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-sm bg-white text-gray-800"
    >
      <option value="" disabled>Selecione uma unidade</option>
      {optionGroups.map((item) => {
        if (typeof item === 'string') {
          return <option key={item} value={item}>{item}</option>;
        }
        return (
          <optgroup key={item.label} label={item.label}>
            {item.options.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </optgroup>
        );
      })}
    </select>
  );
};

export default SelectGroup;