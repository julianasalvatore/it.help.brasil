
import React, { ReactNode } from 'react';

interface CardProps {
  title: string;
  description?: string;
  children: ReactNode;
  required?: boolean;
}

const Card: React.FC<CardProps> = ({ title, description, children, required = false }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden mb-6">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-1">
          {title}
          {required && <span className="text-red-500 ml-1">*</span>}
        </h2>
        {description && <p className="text-sm text-gray-500 mb-4">{description}</p>}
        <div>{children}</div>
      </div>
    </div>
  );
};

export default Card;
