
import React from 'react';

interface RadioGroupProps {
  name: string;
  options: string[];
  selectedValue: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const RadioGroup: React.FC<RadioGroupProps> = ({ name, options, selectedValue, onChange }) => {
  return (
    <div className="space-y-4">
      {options.map((option) => (
        <label key={option} className="flex items-center cursor-pointer">
          <input
            type="radio"
            name={name}
            value={option}
            checked={selectedValue === option}
            onChange={onChange}
            className="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500"
          />
          <span className="ml-3 text-gray-700">{option}</span>
        </label>
      ))}
    </div>
  );
};

export default RadioGroup;
