
import React from 'react';

interface TextAreaProps {
  id: string;
  // FIX: Add `name` prop to TextAreaProps to resolve TypeScript error in App.tsx. The `name` prop is necessary for the `handleInputChange` function.
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  placeholder: string;
  rows?: number;
}

const TextArea: React.FC<TextAreaProps> = ({ id, name, value, onChange, placeholder, rows = 15 }) => {
  return (
    <textarea
      id={id}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      rows={rows}
      className="w-full mt-2 p-4 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-sm font-mono bg-gray-50 text-gray-800"
    />
  );
};

export default TextArea;
